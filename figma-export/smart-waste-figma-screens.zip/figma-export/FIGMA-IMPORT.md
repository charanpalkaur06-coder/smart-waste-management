# Import these screens into Figma (2 minutes)

All PNGs are ready in this folder. **No plugin needed.**

## Steps in Figma

1. Open your file: [Smart Wasre Management](https://www.figma.com/design/NudMsbIEggM4iDsLsrb3dl/Smart-Wasre-Management)
2. On canvas **SWMS Prototype**, press **F** (Frame tool)
3. Create a frame **390 × 844** for mobile screens (or **1440 × 900** for desktop)
4. Menu: **File → Place image…** (or drag PNG from Finder onto the frame)
5. Match files to frames:

| PNG file | Figma frame name | Size |
|----------|------------------|------|
| `01-login.png` | 01 Login | 390×844 |
| `02-manager-dashboard.png` | 02 Manager Dashboard | 1440×900 |
| `04-route-optimisation.png` | 04 Route Optimisation | 1440×900 |
| `05-driver-collection.png` | 05 Driver Collection | 390×844 |
| `06-maintenance.png` | 06 Maintenance | 1440×900 |
| `07-public-report.png` | 07 Issue Report (Public) | 390×844 |
| `07b-public-success.png` | 07b Report Submitted | 390×844 |
| `08-reports-kpis.png` | 08 Reports & KPIs | 1440×900 |
| `09-public-reports-admin.png` | 09 Public Reports (Manager) | 1440×900 |

6. Rename file: **Smart Waste Management** (fix “Wasre” typo)
7. Move old wireframes to a page called **Archive** if you want to keep them

## Optional: make images editable

- Select image → right panel → **Flatten** or trace shapes on top
- Or keep as reference layer at 50% opacity and redraw with Figma components

## Live app (for demos)

```bash
cd ~/Projects/smart-waste-management
./node_modules/.bin/vite preview --port 4173
```

Open http://127.0.0.1:4173
